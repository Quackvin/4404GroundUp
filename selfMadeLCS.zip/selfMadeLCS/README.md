# 4404GroundUp
LCS from scratch boiii

Requirements:
Python3

LCS required packages:
numpy, json, time

Feature extraction required packages:
matplotlib, pickle, re, numpy, json, itertools, os

How to use:
run main.py

parameters and i/o files can be modified in main.main()

## Feature Extraction

| Script | Function | Output Files | Output directory |
|--------|----------|--------------|------------------|
| separatedFeatureExtractor   | Generate class-wise datasets of feature mean and standard deviation from cpickle files. | class data *_data.txt files | features/data/ |
| splitTestAndTrain           | Separates data into testing and training sets with classes evenly represented, based on a given percentage of training data. | data_testing.txt and data_training.txt | features/data/ |
| graphClassifier | Produce plot of a given classifier |classifer plot png file | ./ |
| plotDiffClasses | plot average of averages and std devs | Graphs displayed, not saved | NA |
| plotFromData | plot mean and std dev against mel band for each class, one line for each instance of the class  | multiple graphs as png | ./ |
| plotSpecificClasses | plot mean and std dev against mel band for listed classes, one line for each instance of the class || multiple graphs as png | ./ |
| plotOverlaySlicesAllClasses | plots 10 instances for each class, all timeslices shown | multiple graphs as png | ./ |